<?php
include 'conexion.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cedula = trim($_POST['cedula']);
    $sexo = $_POST['sexo'];
    $email = trim($_POST['email']);
    $nombre = trim($_POST['nombre']);
    $contraseña = $_POST['contraseña'];
    $estado = 1; 

    // Foto en binario
    $foto_binario = file_get_contents($_FILES['imagen']['tmp_name']);

    try {
        // Verificar si la cédula ya existe
        $checkCedula = $conn->prepare("SELECT Cedula FROM Usuarios WHERE Cedula = ?");
        $checkCedula->bind_param("s", $cedula);
        $checkCedula->execute();
        $checkCedula->store_result();

        if ($checkCedula->num_rows > 0) {
            $error = "⚠️ La cédula ingresada ya está registrada.";
        } else {
            // Verificar si el email ya existe
            $checkEmail = $conn->prepare("SELECT Email FROM Usuarios WHERE Email = ?");
            $checkEmail->bind_param("s", $email);
            $checkEmail->execute();
            $checkEmail->store_result();

            if ($checkEmail->num_rows > 0) {
                $error = "⚠️ El correo ingresado ya está registrado.";
            } else {
                // Insertar nuevo usuario
                $sql = "INSERT INTO Usuarios (Cedula, Sexo, Email, Nombre, Foto, Contrasenia, Estado) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);

                // Vinculamos parámetros (Foto se pasa como NULL y luego binario)
                $null = NULL;
                $stmt->bind_param("ssssbsi", $cedula, $sexo, $email, $nombre, $null, $contraseña, $estado);

                // Enviar foto como binario
                $stmt->send_long_data(4, $foto_binario);

                $stmt->execute();

                header("Location: Login.html");
                exit();
            }
            $checkEmail->close();
        }
        $checkCedula->close();

    } catch (mysqli_sql_exception $e) {
        $error = "Error en la base de datos: " . $e->getMessage();
    }

    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>

<!-- Mostrar el formulario y el error si existe -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/registro.css">
    <title>Registro</title>
</head>
<body>
    <div class="registro-contenedor">
        <img src="img/logoweb.png" alt="Logo" class="registro-logo">
        <form class="registro-formulario" action="register.php" method="POST" enctype="multipart/form-data">
            <h2>Registro</h2>
            <?php if (!empty($error)): ?>
                <div style="background:#ffe6e6; border:1px solid #cc0000; color:#cc0000; padding:10px; margin-bottom:15px; text-align:center; font-weight:bold; border-radius:5px;">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            <input type="text" name="nombre" placeholder="Nombre completo" required>
            <input type="text" name="cedula" placeholder="Cédula" required>
            <input type="email" name="email" placeholder="Correo electrónico" required>
            <input type="password" name="contraseña" placeholder="Contraseña" required>
            <label style="margin-bottom: 8px; font-size:15px;">Sube tu foto:</label>
            <input type="file" name="imagen" accept="image/*" required>
            <label style="margin-top: 10px; margin-bottom: 5px; font-size:15px;">Sexo:</label>
            <select name="sexo" required>
                <option value="">Seleccione sexo</option>
                <option value="M">Masculino</option>
                <option value="F">Femenino</option>
                <option value="O">Otro</option>
            </select>
            <button type="submit">Registrarse</button>
        </form>
    </div>
</body>
</html>
