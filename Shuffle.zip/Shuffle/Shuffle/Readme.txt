Thanks for downloading this template!

Template Name: Shuffle
Template URL: https://bootstrapmade.com/bootstrap-3-one-page-template-free-shuffle/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
